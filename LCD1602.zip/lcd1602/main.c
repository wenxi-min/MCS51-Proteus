#include "reg51.h"
#include "lcd1602.h"


void main()
{	
	LCD_Init();
	while(1)
	{
//		LCD_ShowChar(1,1,'a');
//		LCD_ShowString(1,3,"lcz");
//		LCD_ShowNum(2,1,666,3);
//		LCD_ShowSignedNum(2,1,-33,2);
//		LCD_ShowHexNum(2,1,256,4);
//		LCD_ShowBinNum(2,1,5,4);
	}

}
 

