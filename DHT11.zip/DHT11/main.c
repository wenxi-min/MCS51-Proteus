#include "reg51.h"
#include "lcd1602.h"
#include "dht11.h"

unsigned int* dht;

void main()
{	
	LCD_Init();
	while(1)
	{
		
		dht=DHT11_receive();
		LCD_ShowNum(1,1,dht[0],2);//ʪ��
		LCD_ShowString(1,3,"%RH");
		LCD_ShowNum(2,1,dht[1],2);//�¶�
		LCD_ShowString(2,3,"^C");		

	}

}
 

