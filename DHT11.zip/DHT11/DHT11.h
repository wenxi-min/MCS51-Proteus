#ifndef __DHT11_H__
#define __DHT11_H__


unsigned int* DHT11_receive();
 
#endif