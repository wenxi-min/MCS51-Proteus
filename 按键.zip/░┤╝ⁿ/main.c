#include "reg52.h"
#include "lcd1602.h"

#define KEY P1

sbit key_one=P2^5;

typedef unsigned int u16;	  //���������ͽ�����������
typedef unsigned char u8;

u8 keyvalue;

void delay(u16 i)
{
	while(i--);	
}

void keyone()
{
	if(key_one==0)
	{
		delay(1000);
		if(key_one==0)
		{
			keyvalue=66;		
		}
		while(!key_one);
		
	}
}

void keyscan()
{
	char key_x=0,key_y=0;
	KEY=0XF0;
	if(KEY!=0XF0)
	{
		delay(1000);
		if(KEY!=0XF0)
		{
			KEY=0XF0;
			switch(KEY)
			{
				case(0xe0):key_x=0;break;
				case(0xd0):key_x=1;break;
				case(0xb0):key_x=2;break;
				case(0x70):key_x=3;break;
			}
			KEY=0X0F;
			switch(KEY)
			{
				case(0x07):key_y=3;break;
				case(0x0B):key_y=2;break;
				case(0x0D):key_y=1;break;
				case(0x0E):key_y=0;break;
			}			
			keyvalue=key_x*4+key_y;
		}
		
	}
}

void main()
{
	LCD_Init();
	while(1)
	{
		keyone();
    keyscan();
		LCD_ShowNum(1,1,keyvalue,2);		
	}

}